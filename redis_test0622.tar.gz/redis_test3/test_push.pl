for($i=1;$i<100000;$i++){
           	   print `./redis-cli qpush 116 $i`;	  }
